"""
inherited view
"""

from odoo import models, fields, api


class ResPartner(models.Model):
    _inherit = 'res.partner'

    _description = 'Res Partner'

    ngo_check = fields.Boolean(string="NGO")
    orphan_members = fields.Integer(compute='total_orphan_members')
    # amount = fields.Integer(compute='total_orphan_members')

    @api.onchange('company_type')
    def onchange_company_type_ngo(self):
        # res = self.env['res.partner',self]
        print("\n ------------------------------", self)
        for rec in self:
            print("\n ------------------------------", rec.company_type)
            if rec.company_type == 'person':
                print("\n ------------------------------",rec.ngo_check)
                rec.ngo_check = False

    # def compute_total_amount(self):
    #     for org in self:
    #         donation = sum([each.amount for each in self.env['orphans.organization.donation'].search([('ngo_id', '=', org.id)])])
    #         expense = sum([each.expense_amount for each in self.env['orphans.organization.expense'].search([('ngo_id', '=', org.id)])])
    #         org.amount = donation-expense

    def total_orphan_members(self):

        """
        counting courses 'not yet complete'
        """
        for rec in self:
            res = self.env['orphans.member'].search_count([("ngo_name", "=", rec.name)])
            rec.orphan_members = res

    def total_available_funds(self):
        pass
        # for rec in self:
        #     amount_count = self.env['orphans.member'].search_count([])
        #     rec.orphan_members = amount_count
